package com.css152lgroup10.noodlemoneybuddy.data.model

class Order {
}