package com.css152lgroup10.noodlemoneybuddy.data.model
data class SalesStatistics(
    val totalSales: Double,
    val totalOrders: Int,
    val averageOrderValue: Double,
    val salesByDate: Map<String, Double>,
    val topItems: List<Pair<String, Int>>
)