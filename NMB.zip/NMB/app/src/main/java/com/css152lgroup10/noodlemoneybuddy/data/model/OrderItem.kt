package com.css152lgroup10.noodlemoneybuddy.data.model

data class OrderItem(
    val name: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double = quantity * unitPrice
)